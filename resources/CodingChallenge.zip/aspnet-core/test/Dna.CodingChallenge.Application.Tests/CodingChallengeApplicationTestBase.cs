﻿namespace Dna.CodingChallenge
{
    public abstract class CodingChallengeApplicationTestBase : CodingChallengeTestBase<CodingChallengeApplicationTestModule> 
    {

    }
}
