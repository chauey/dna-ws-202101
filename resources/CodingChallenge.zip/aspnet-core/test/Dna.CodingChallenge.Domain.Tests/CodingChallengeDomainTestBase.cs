﻿namespace Dna.CodingChallenge
{
    public abstract class CodingChallengeDomainTestBase : CodingChallengeTestBase<CodingChallengeDomainTestModule> 
    {

    }
}
