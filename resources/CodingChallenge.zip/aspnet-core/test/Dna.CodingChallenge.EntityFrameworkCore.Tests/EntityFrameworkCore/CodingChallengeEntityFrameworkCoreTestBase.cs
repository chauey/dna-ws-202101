﻿using Volo.Abp;

namespace Dna.CodingChallenge.EntityFrameworkCore
{
    public abstract class CodingChallengeEntityFrameworkCoreTestBase : CodingChallengeTestBase<CodingChallengeEntityFrameworkCoreTestModule> 
    {

    }
}
