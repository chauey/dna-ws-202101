﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Dna.CodingChallenge.EntityFrameworkCore.Tests")]
