﻿namespace Dna.CodingChallenge.Settings
{
    public static class CodingChallengeSettings
    {
        private const string Prefix = "CodingChallenge";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}