﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Dna.CodingChallenge.Domain.Tests")]
[assembly:InternalsVisibleToAttribute("Dna.CodingChallenge.TestBase")]
