﻿namespace Dna.CodingChallenge
{
    public static class CodingChallengeConsts
    {
        public const string DbTablePrefix = "App";

        public const string DbSchema = null;
    }
}
