using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;

namespace Dna.CodingChallenge.Pages
{
    public class IndexModel : AbpPageModel
    {
        public void OnGet()
        {
        }
    }
}