﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Dna.CodingChallenge.Application.Tests")]
