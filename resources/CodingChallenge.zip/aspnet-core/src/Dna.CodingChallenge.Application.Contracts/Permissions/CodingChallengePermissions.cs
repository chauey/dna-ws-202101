﻿namespace Dna.CodingChallenge.Permissions
{
    public static class CodingChallengePermissions
    {
        public const string GroupName = "CodingChallenge";

        //Add your own permission names. Example:
        //public const string MyPermission1 = GroupName + ".MyPermission1";
    }
}