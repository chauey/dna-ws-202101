﻿namespace Dna.CodingChallenge
{
    public static class CodingChallengeDomainErrorCodes
    {
        /* You can add your business exception error codes here, as constants */
    }
}
