﻿using Volo.Abp.Localization;

namespace Dna.CodingChallenge.Localization
{
    [LocalizationResourceName("CodingChallenge")]
    public class CodingChallengeResource
    {

    }
}